package example.ru.masha;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void sumOfElements (View v){
        EditText b1 = (EditText)findViewById(R.id.FirstNumber);
        EditText b2 = (EditText)findViewById(R.id.SecondNumber);
        TextView r = (TextView)findViewById(R.id.Result);
        int num1 = Integer.parseInt(b1.getText().toString());
        int num2 = Integer.parseInt(b2.getText().toString());
        int res = num1+num2;
        r.setText(Integer.toString(res));
    }

    public void minOfElements (View v){
        EditText b1 = (EditText)findViewById(R.id.FirstNumber);
        EditText b2 = (EditText)findViewById(R.id.SecondNumber);
        TextView r = (TextView)findViewById(R.id.Result);
        int num1 = Integer.parseInt(b1.getText().toString());
        int num2 = Integer.parseInt(b2.getText().toString());
        int res = num1-num2;
        r.setText(Integer.toString(res));
    }

    public void mulOfElements (View v){
        EditText b1 = (EditText)findViewById(R.id.FirstNumber);
        EditText b2 = (EditText)findViewById(R.id.SecondNumber);
        TextView r = (TextView)findViewById(R.id.Result);
        int num1 = Integer.parseInt(b1.getText().toString());
        int num2 = Integer.parseInt(b2.getText().toString());
        int res = num1*num2;
        r.setText(Integer.toString(res));
    }

    public void divOfElements (View v){
        EditText b1 = (EditText)findViewById(R.id.FirstNumber);
        EditText b2 = (EditText)findViewById(R.id.SecondNumber);
        TextView r = (TextView)findViewById(R.id.Result);
        int num1 = Integer.parseInt(b1.getText().toString());
        int num2 = Integer.parseInt(b2.getText().toString());
        int res = num1/num2;
        r.setText(Integer.toString(res));
    }
}
